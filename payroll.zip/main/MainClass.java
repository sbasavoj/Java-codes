package com.cg.payroll.main;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServicesImpl;
//import com.cg.payroll.beans.BankDetails;
//import com.cg.payroll.beans.Salary;
public class MainClass {

	public static void main(String[] args) {
		PayrollServicesImpl payrollServies=new PayrollServicesImpl();
		int associateId=payrollServies.acceptAssociateDetails(150000, "Srividya", "Basavoju", "java", "trainee", "135FHJY", "vidya@gmail.com", 100000, 1000, 1000, 12345, "ICICI", "icici123");
		System.out.println("Associate ID:"+associateId);
		System.out.println("Name        :"+payrollServies.getAssociateDetails(associateId).getFirstName());
		System.out.println("Salary      :"+payrollServies.calculateNetSAlary(associateId));
		System.out.println("Monthly Tax :"+payrollServies.getAssociateDetails(associateId).getSalary().getMonthlyTax());
	}

}
